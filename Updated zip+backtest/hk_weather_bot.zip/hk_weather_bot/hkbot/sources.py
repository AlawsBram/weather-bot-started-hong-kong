"""Data fetchers: Polymarket (Gamma API), Hong Kong Observatory open data, Open-Meteo models.

Every fetcher is defensive: providers change formats, so failures return None /
empty results and the bot carries on with the sources it does have.
"""
from __future__ import annotations

import csv
import io
import json
import logging
import time
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo

import requests

from . import config
from .buckets import Bucket, parse_label

log = logging.getLogger(__name__)
HKT = ZoneInfo(config.HK_TZ)
_session = requests.Session()
_session.headers["User-Agent"] = "hk-weather-paper-bot/0.1 (research; paper trading)"


def _get(url: str, params: dict | None = None, retries: int = 2, timeout: int = 20):
    last = None
    for attempt in range(retries + 1):
        try:
            r = _session.get(url, params=params, timeout=timeout)
            r.raise_for_status()
            return r
        except requests.RequestException as e:  # network / HTTP errors
            last = e
            time.sleep(1.5 * (attempt + 1))
    log.warning("GET failed %s %s: %s", url, params, last)
    return None


# ----------------------------------------------------------------------------
# Polymarket
# ----------------------------------------------------------------------------

def event_slug(d: date) -> str:
    return f"highest-temperature-in-hong-kong-on-{d.strftime('%B').lower()}-{d.day}-{d.year}"


@dataclass
class MarketBucket:
    bucket: Bucket
    yes_bid: float | None      # best price someone will pay for YES (you sell YES / buy NO at 1-bid)
    yes_ask: float | None      # best price to buy YES
    yes_price: float | None    # displayed probability (Polymarket outcomePrices)
    resolved_yes: bool | None  # True/False once settled, None while open
    volume: float = 0.0

    @property
    def mid(self) -> float | None:
        if self.yes_bid is not None and self.yes_ask is not None and self.yes_ask >= self.yes_bid:
            return (self.yes_bid + self.yes_ask) / 2
        return self.yes_price


@dataclass
class MarketSnapshot:
    slug: str
    date: date
    buckets: list[MarketBucket]
    closed: bool
    fetched_at: datetime

    @property
    def url(self) -> str:
        return config.POLYMARKET_EVENT_PAGE.format(slug=self.slug)

    def winner(self) -> MarketBucket | None:
        won = [b for b in self.buckets if b.resolved_yes]
        return won[0] if len(won) == 1 else None

    def leader(self) -> MarketBucket | None:
        priced = [b for b in self.buckets if b.yes_price is not None]
        return max(priced, key=lambda b: b.yes_price) if priced else None


def _f(x) -> float | None:
    try:
        return None if x in (None, "") else float(x)
    except (TypeError, ValueError):
        return None


def _json_list(x) -> list:
    if isinstance(x, list):
        return x
    if isinstance(x, str):
        try:
            return json.loads(x)
        except json.JSONDecodeError:
            return []
    return []


def parse_gamma_event(event: dict, d: date) -> MarketSnapshot:
    buckets: list[MarketBucket] = []
    for m in event.get("markets", []):
        label = m.get("groupItemTitle") or m.get("question", "")
        try:
            b = parse_label(label)
        except ValueError:
            log.warning("Skipping unparseable bucket %r", label)
            continue
        prices = [_f(p) for p in _json_list(m.get("outcomePrices"))]
        yes_price = prices[0] if prices else None
        resolved = None
        if m.get("closed") and yes_price is not None and yes_price in (0.0, 1.0):
            resolved = yes_price == 1.0
        buckets.append(MarketBucket(
            bucket=b,
            yes_bid=_f(m.get("bestBid")),
            yes_ask=_f(m.get("bestAsk")),
            yes_price=yes_price,
            resolved_yes=resolved,
            volume=_f(m.get("volume")) or 0.0,
        ))
    buckets.sort(key=lambda mb: mb.bucket.lo)
    return MarketSnapshot(
        slug=event.get("slug", event_slug(d)),
        date=d,
        buckets=buckets,
        closed=bool(event.get("closed")),
        fetched_at=datetime.now(HKT),
    )


def fetch_market(d: date) -> MarketSnapshot | None:
    slug = event_slug(d)
    r = _get(config.GAMMA_EVENTS_URL, {"slug": slug})
    if r is None:
        return None
    data = r.json()
    events = data if isinstance(data, list) else [data]
    if not events or not events[0]:
        log.warning("No Polymarket event for %s", slug)
        return None
    return parse_gamma_event(events[0], d)


# ----------------------------------------------------------------------------
# Hong Kong Observatory
# ----------------------------------------------------------------------------

def fetch_hko_9day() -> dict[date, float]:
    """Official HKO forecast max for each of the next 9 days (whole degrees)."""
    r = _get(config.HKO_OPENDATA_WEATHER, {"dataType": "fnd", "lang": "en"})
    out: dict[date, float] = {}
    if r is None:
        return out
    for day in r.json().get("weatherForecast", []):
        try:
            d = datetime.strptime(day["forecastDate"], "%Y%m%d").date()
            out[d] = float(day["forecastMaxtemp"]["value"])
        except (KeyError, ValueError, TypeError):
            continue
    return out


def fetch_hko_max_since_midnight() -> float | None:
    """Today's running max at the HKO station, one decimal (None if unavailable)."""
    r = _get(config.HKO_SINCE_MIDNIGHT_CSV)
    if r is None:
        return None
    text = r.content.decode("utf-8-sig", errors="replace")
    for row in csv.reader(io.StringIO(text)):
        if len(row) >= 3 and row[1].strip().lower() == "hong kong observatory":
            return _f(row[2].strip())
    return None


def parse_clmmaxt(payload) -> dict[date, float]:
    """Parse HKO CLMMAXT (daily max) open-data JSON: rows like ["2026","10","15","29.7","C"]."""
    rows = payload.get("data", []) if isinstance(payload, dict) else []
    out: dict[date, float] = {}
    for row in rows:
        try:
            y, m, d, v = int(row[0]), int(row[1]), int(row[2]), float(row[3])
            out[date(y, m, d)] = v
        except (ValueError, TypeError, IndexError):
            continue
    return out


def fetch_hko_daily_max(year: int, month: int) -> dict[date, float]:
    """Absolute daily max at HKO HQ — the same figure the market resolves on."""
    r = _get(config.HKO_OPENDATA_CLIMATE, {
        "dataType": "CLMMAXT", "rformat": "json", "station": "HKO",
        "year": year, "month": month,
    })
    if r is None:
        return {}
    try:
        return parse_clmmaxt(r.json())
    except json.JSONDecodeError:
        return {}


def fetch_hko_daily_max_range(start: date, end: date) -> dict[date, float]:
    out: dict[date, float] = {}
    y, m = start.year, start.month
    while (y, m) <= (end.year, end.month):
        out.update(fetch_hko_daily_max(y, m))
        y, m = (y + 1, 1) if m == 12 else (y, m + 1)
    return {d: v for d, v in out.items() if start <= d <= end}


# ----------------------------------------------------------------------------
# Open-Meteo (ECMWF / GFS / ICON at the HKO station point, hourly -> daily max)
# ----------------------------------------------------------------------------

def _daily_max_from_hourly(payload: dict, key: str) -> dict[date, float]:
    hourly = payload.get("hourly", {})
    times, temps = hourly.get("time", []), hourly.get(key, [])
    out: dict[date, float] = {}
    for t, v in zip(times, temps):
        if v is None:
            continue
        d = datetime.fromisoformat(t).date()
        out[d] = max(out.get(d, -99.0), float(v))
    return out


def fetch_model_forecasts(start: date, end: date, historical: bool = False) -> dict[str, dict[date, float]]:
    """{source_name: {date: forecast daily max}} for each configured model."""
    url = config.OPEN_METEO_HISTORICAL_FORECAST if historical else config.OPEN_METEO_FORECAST
    out: dict[str, dict[date, float]] = {}
    for model_id, name in config.MODEL_SOURCES.items():
        r = _get(url, {
            "latitude": config.HKO_LAT, "longitude": config.HKO_LON,
            "hourly": "temperature_2m", "models": model_id,
            "timezone": config.HK_TZ,
            "start_date": start.isoformat(), "end_date": end.isoformat(),
        })
        if r is None:
            continue
        payload = r.json()
        key = "temperature_2m" if "temperature_2m" in payload.get("hourly", {}) else f"temperature_2m_{model_id}"
        series = _daily_max_from_hourly(payload, key)
        if series:
            out[name] = series
    return out


def now_hkt() -> datetime:
    return datetime.now(HKT)


def today_hkt() -> date:
    return now_hkt().date()


def tomorrow_hkt() -> date:
    return today_hkt() + timedelta(days=1)
