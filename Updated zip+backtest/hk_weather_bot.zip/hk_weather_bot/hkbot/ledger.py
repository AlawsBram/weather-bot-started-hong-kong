"""SQLite ledger: every forecast, prediction, paper trade and result is recorded,
tagged by strategy version, so versions can be compared side by side."""
from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from pathlib import Path

from . import config

SCHEMA = """
CREATE TABLE IF NOT EXISTS forecasts (
    run_ts TEXT, target_date TEXT, source TEXT, value REAL,
    PRIMARY KEY (run_ts, target_date, source)
);
CREATE TABLE IF NOT EXISTS observations (
    ts TEXT PRIMARY KEY, obs_date TEXT, max_so_far REAL
);
CREATE TABLE IF NOT EXISTS predictions (
    run_ts TEXT, target_date TEXT, version TEXT, label TEXT, lo REAL, hi REAL,
    model_p REAL, final_p REAL, market_p REAL, yes_bid REAL, yes_ask REAL,
    fc_mean REAL, fc_sigma REAL,
    PRIMARY KEY (run_ts, target_date, version, label)
);
CREATE TABLE IF NOT EXISTS trades (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_ts TEXT, target_date TEXT, version TEXT, label TEXT, side TEXT,
    price REAL, prob REAL, edge REAL, shares REAL, stake REAL,
    pnl REAL, settled INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS results (
    target_date TEXT PRIMARY KEY, winner_label TEXT, hko_reading REAL,
    cutoff_consistent INTEGER, source TEXT, settled_ts TEXT
);
CREATE TABLE IF NOT EXISTS scores (
    target_date TEXT, version TEXT, run_ts TEXT,
    brier_bot REAL, brier_market REAL, logloss_bot REAL, logloss_market REAL,
    p_winner_bot REAL, p_winner_market REAL, pnl REAL,
    PRIMARY KEY (target_date, version)
);
"""


def connect(path: Path | None = None) -> sqlite3.Connection:
    path = path or config.DB_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(path)
    con.row_factory = sqlite3.Row
    con.executescript(SCHEMA)
    return con


@contextmanager
def db(path: Path | None = None):
    con = connect(path)
    try:
        yield con
        con.commit()
    finally:
        con.close()
